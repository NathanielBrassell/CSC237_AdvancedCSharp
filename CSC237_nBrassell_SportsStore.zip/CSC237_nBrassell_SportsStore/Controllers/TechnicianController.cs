﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CSC237_nBrassell_SportsStore.Models;

namespace CSC237_nBrassell_SportsStore.Controllers
{
    public class TechnicianController : Controller
    {
        private readonly ITechnicianRepository _technicianRepository;

        public TechnicianController(ITechnicianRepository technicianRepository)
        {
            _technicianRepository = technicianRepository;
        }

        public IActionResult List()
        {
            ViewBag.Title = "Technician Manager";

            var technicianList = _technicianRepository.GetTechnicians.ToList();

            return View(technicianList);
        }

        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("AddEdit", new Technician());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var technician = _technicianRepository.GetTechnicianById(id);
            return View("AddEdit", technician);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var technician = _technicianRepository.GetTechnicianById(id);
            return View(technician);
        }

        [HttpPost]
        public IActionResult Delete(Technician technician)
        {
            return RedirectToAction("List");
        }
    }
}
