﻿using CSC237_nBrassell_SportsStore.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSC237_nBrassell_SportsStore.Controllers
{
    public class IncidentController : Controller
    {
        private readonly IIncidentRepository _incidentRepository;

        public IncidentController(IIncidentRepository productRepository)
        {
            _incidentRepository = productRepository;
        }

        public IActionResult List()
        {
            ViewBag.Title = "Incident List";

            var incidentList = _incidentRepository.GetIncidents.ToList();

            return View(incidentList);
        }

        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("AddEdit", new Product());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var incident = _incidentRepository.GetIncidentById(id);
            return View("AddEdit", incident);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var incident = _incidentRepository.GetIncidentById(id);
            return View(incident);
        }

        [HttpPost]
        public IActionResult Delete(Incident incident)
        {
            return RedirectToAction("List");
        }
    }
}
