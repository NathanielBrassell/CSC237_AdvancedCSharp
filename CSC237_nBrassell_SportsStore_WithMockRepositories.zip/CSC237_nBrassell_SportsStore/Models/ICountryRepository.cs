﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSC237_nBrassell_SportsStore.Models
{
    interface ICountryRepository
    {
        IEnumerable<Country> GetCountries { get; }

        Country GetCountryById(string CountryId);
    }
}
