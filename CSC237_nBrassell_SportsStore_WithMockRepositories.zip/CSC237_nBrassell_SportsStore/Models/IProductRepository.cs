﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSC237_nBrassell_SportsStore.Models
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetProducts { get; }

        Product GetProductById(int ProductId);
    }
}
